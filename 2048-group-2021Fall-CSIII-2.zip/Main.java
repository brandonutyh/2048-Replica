import java.util.*;
import java.io.*;

class Main {
  public static void main(String[] args) throws IOException
  {
    File f = new File("bestScore.dat");
    Game g = new Game(f);
    
    
    

  }
}